# Framework Shootout — Benchmark Report

**Generated:** 2026-02-17 10:38 UTC  
**Frameworks:** flask, django, fastapi, aquilia, sanic, tornado  
**Scenarios:** ping, json, db-read, db-write, upload, stream, websocket, query, path, json-large, html  
**Python:** 3.11 (Docker, 2 CPU / 512MB per container)  

---

## PING

| # | Framework | Req/s | p50 (ms) | p95 (ms) | p99 (ms) | Errors | CPU % | Mem (MiB) | Runs |
|---|-----------|------:|--------:|--------:|--------:|------:|------:|--------:|-----:|
| 🥇1 | **sanic** | 38,755 | 0.66 | 0.00 | 50.03 | 0 | 0.0 | 0 | 1 |
| 🥈2 | **fastapi** | 26,626 | 1.06 | 0.00 | 47.41 | 0 | 0.0 | 0 | 1 |
| 🥉3 | **tornado** | 13,084 | 3.53 | 0.00 | 5.93 | 0 | 0.0 | 0 | 1 |
| 4 | **aquilia** | 11,228 | 2.35 | 0.00 | 53.25 | 0 | 0.0 | 0 | 1 |
| 5 | **flask** | 8,117 | 3.98 | 0.00 | 57.65 | 0 | 0.0 | 0 | 1 |
| 6 | **django** | 7,636 | 4.16 | 0.00 | 54.14 | 0 | 0.0 | 0 | 1 |

## JSON

| # | Framework | Req/s | p50 (ms) | p95 (ms) | p99 (ms) | Errors | CPU % | Mem (MiB) | Runs |
|---|-----------|------:|--------:|--------:|--------:|------:|------:|--------:|-----:|
| 🥇1 | **sanic** | 20,623 | 1.41 | 0.00 | 48.76 | 0 | 0.0 | 0 | 1 |
| 🥈2 | **fastapi** | 17,114 | 1.58 | 0.00 | 49.83 | 0 | 0.0 | 0 | 1 |
| 🥉3 | **tornado** | 8,735 | 5.16 | 0.00 | 39.98 | 0 | 0.0 | 0 | 1 |
| 4 | **aquilia** | 6,810 | 4.52 | 0.00 | 56.09 | 0 | 0.0 | 0 | 1 |
| 5 | **flask** | 6,537 | 4.78 | 0.00 | 58.81 | 0 | 0.0 | 0 | 1 |
| 6 | **django** | 6,003 | 5.53 | 0.00 | 54.30 | 0 | 0.0 | 0 | 1 |

## DB-READ

| # | Framework | Req/s | p50 (ms) | p95 (ms) | p99 (ms) | Errors | CPU % | Mem (MiB) | Runs |
|---|-----------|------:|--------:|--------:|--------:|------:|------:|--------:|-----:|
| 🥇1 | **flask** | 2,762 | 11.34 | 0.00 | 65.25 | 0 | 0.0 | 0 | 1 |
| 🥈2 | **django** | 2,735 | 11.08 | 0.00 | 67.69 | 0 | 0.0 | 0 | 1 |
| 🥉3 | **fastapi** | 1,942 | 17.70 | 0.00 | 94.54 | 2330 | 0.0 | 0 | 1 |

## DB-WRITE

| # | Framework | Req/s | p50 (ms) | p95 (ms) | p99 (ms) | Errors | CPU % | Mem (MiB) | Runs |
|---|-----------|------:|--------:|--------:|--------:|------:|------:|--------:|-----:|
| 🥇1 | **django** | 2,438 | 13.60 | 52.40 | 58.90 | 0 | 0.0 | 0 | 1 |
| 🥈2 | **flask** | 2,174 | 11.20 | 66.60 | 70.90 | 0 | 0.0 | 0 | 1 |
| 🥉3 | **fastapi** | 1,587 | 30.60 | 82.00 | 137.50 | 1807 | 0.0 | 0 | 1 |

## UPLOAD

| # | Framework | Req/s | p50 (ms) | p95 (ms) | p99 (ms) | Errors | CPU % | Mem (MiB) | Runs |
|---|-----------|------:|--------:|--------:|--------:|------:|------:|--------:|-----:|
| 🥇1 | **fastapi** | 258 | 85.00 | 113.10 | 275.70 | 0 | 0.0 | 0 | 1 |
| 🥈2 | **sanic** | 223 | 90.10 | 168.20 | 223.00 | 0 | 0.0 | 0 | 1 |
| 🥉3 | **tornado** | 187 | 105.20 | 117.30 | 131.50 | 0 | 0.0 | 0 | 1 |
| 4 | **django** | 162 | 106.00 | 203.20 | 213.70 | 834 | 0.0 | 0 | 1 |
| 5 | **flask** | 84 | 199.30 | 516.20 | 594.30 | 0 | 0.0 | 0 | 1 |

## STREAM

| # | Framework | Req/s | p50 (ms) | p95 (ms) | p99 (ms) | Errors | CPU % | Mem (MiB) | Runs |
|---|-----------|------:|--------:|--------:|--------:|------:|------:|--------:|-----:|
| 🥇1 | **sanic** | 597 | 24.56 | 0.00 | 90.70 | 0 | 0.0 | 0 | 1 |
| 🥈2 | **fastapi** | 542 | 28.66 | 0.00 | 101.24 | 0 | 0.0 | 0 | 1 |
| 🥉3 | **django** | 487 | 27.42 | 0.00 | 92.66 | 0 | 0.0 | 0 | 1 |
| 4 | **flask** | 441 | 33.37 | 0.00 | 106.27 | 0 | 0.0 | 0 | 1 |
| 5 | **tornado** | 282 | 67.62 | 0.00 | 180.81 | 0 | 0.0 | 0 | 1 |

## QUERY

| # | Framework | Req/s | p50 (ms) | p95 (ms) | p99 (ms) | Errors | CPU % | Mem (MiB) | Runs |
|---|-----------|------:|--------:|--------:|--------:|------:|------:|--------:|-----:|
| 🥇1 | **sanic** | 20,358 | 1.45 | 0.00 | 51.18 | 0 | 0.0 | 0 | 1 |
| 🥈2 | **fastapi** | 10,591 | 2.59 | 0.00 | 54.65 | 0 | 0.0 | 0 | 1 |
| 🥉3 | **tornado** | 7,208 | 6.87 | 0.00 | 10.62 | 0 | 0.0 | 0 | 1 |
| 4 | **aquilia** | 6,604 | 4.36 | 0.00 | 57.72 | 0 | 0.0 | 0 | 1 |
| 5 | **flask** | 4,102 | 6.96 | 0.00 | 64.98 | 0 | 0.0 | 0 | 1 |

## PATH

| # | Framework | Req/s | p50 (ms) | p95 (ms) | p99 (ms) | Errors | CPU % | Mem (MiB) | Runs |
|---|-----------|------:|--------:|--------:|--------:|------:|------:|--------:|-----:|
| 🥇1 | **sanic** | 37,656 | 0.68 | 0.00 | 51.11 | 0 | 0.0 | 0 | 1 |
| 🥈2 | **fastapi** | 16,149 | 1.68 | 0.00 | 53.35 | 0 | 0.0 | 0 | 1 |
| 🥉3 | **tornado** | 13,943 | 3.30 | 0.00 | 6.96 | 0 | 0.0 | 0 | 1 |
| 4 | **aquilia** | 11,698 | 2.30 | 0.00 | 55.24 | 0 | 0.0 | 0 | 1 |
| 5 | **flask** | 5,545 | 5.83 | 0.00 | 61.35 | 0 | 0.0 | 0 | 1 |

## HTML

| # | Framework | Req/s | p50 (ms) | p95 (ms) | p99 (ms) | Errors | CPU % | Mem (MiB) | Runs |
|---|-----------|------:|--------:|--------:|--------:|------:|------:|--------:|-----:|
| 🥇1 | **sanic** | 39,156 | 0.68 | 0.00 | 50.86 | 0 | 0.0 | 0 | 1 |
| 🥈2 | **fastapi** | 23,894 | 1.16 | 0.00 | 51.95 | 0 | 0.0 | 0 | 1 |
| 🥉3 | **tornado** | 14,823 | 3.16 | 0.00 | 5.36 | 0 | 0.0 | 0 | 1 |
| 4 | **aquilia** | 11,270 | 2.52 | 0.00 | 54.79 | 0 | 0.0 | 0 | 1 |
| 5 | **flask** | 6,197 | 4.17 | 0.00 | 61.36 | 0 | 0.0 | 0 | 1 |

---

## Executive Summary

### Winner per Scenario

| Scenario | Winner | Req/s | Runner-up | Req/s |
|----------|--------|------:|-----------|------:|
| ping | **sanic** | 38,755 | fastapi | 26,626 |
| json | **sanic** | 20,623 | fastapi | 17,114 |
| db-read | **flask** | 2,762 | django | 2,735 |
| db-write | **django** | 2,438 | flask | 2,174 |
| upload | **fastapi** | 258 | sanic | 223 |
| stream | **sanic** | 597 | fastapi | 542 |
| query | **sanic** | 20,358 | fastapi | 10,591 |
| path | **sanic** | 37,656 | fastapi | 16,149 |
| html | **sanic** | 39,156 | fastapi | 23,894 |

### Overall Winner: **sanic** (6/11 scenarios)

### Analysis Notes

- **Ping/JSON** (tiny payload): Measures pure request-routing overhead.
  Async frameworks (FastAPI, Aquilia, Sanic) typically dominate due to
  event-loop efficiency vs. gunicorn process model.

- **DB-read/write**: Async frameworks using `asyncpg` have an advantage
  over sync frameworks using `psycopg2` with thread pools.

- **Upload**: Tests I/O handling. Memory consumption matters here.

- **Stream**: Tests chunked transfer. Async generators are natural fit.

- **WebSocket**: Only async frameworks support this natively.
  Flask and Django are excluded from this scenario.

---

## Methodology

- **Isolation:** Each framework runs in its own Docker container (2 CPU, 512MB).
- **DB:** PostgreSQL 16 with shared schema and 1000 seeded rows.
- **Workers:** Sync (Flask/Django): gunicorn 4w×2t. Async: uvicorn/sanic 4 workers.
- **Load:** `wrk` for GET, `hey` for POST. 50 concurrent, 3 min steady-state.
- **Warmup:** 30s before each measurement.
- **Repetitions:** 3 runs per scenario, median reported.
- **Correctness:** Each endpoint validated before load test.
