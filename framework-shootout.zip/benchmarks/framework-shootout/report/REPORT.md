# Framework Shootout — Benchmark Report

**Generated:** 2026-02-17 10:02 UTC  
**Frameworks:** flask, django, fastapi, aquilia, sanic, tornado  
**Scenarios:** ping, json, db-read, db-write, upload, stream, websocket  
**Python:** 3.11 (Docker, 2 CPU / 512MB per container)  

---

## PING

| # | Framework | Req/s | p50 (ms) | p95 (ms) | p99 (ms) | Errors | CPU % | Mem (MiB) | Runs |
|---|-----------|------:|--------:|--------:|--------:|------:|------:|--------:|-----:|
| 🥇1 | **sanic** | 40,594 | 0.63 | 0.00 | 50.77 | 0 | 0.0 | 0 | 1 |
| 🥈2 | **fastapi** | 34,194 | 0.78 | 0.00 | 51.13 | 0 | 0.0 | 0 | 1 |
| 🥉3 | **aquilia** | 13,798 | 1.96 | 0.00 | 53.27 | 0 | 0.0 | 0 | 1 |
| 4 | **flask** | 6,701 | 5.29 | 0.00 | 63.16 | 0 | 0.0 | 0 | 1 |
| 5 | **django** | 6,304 | 4.45 | 0.00 | 62.17 | 0 | 0.0 | 0 | 1 |

---

## Executive Summary

### Winner per Scenario

| Scenario | Winner | Req/s | Runner-up | Req/s |
|----------|--------|------:|-----------|------:|
| ping | **sanic** | 40,594 | fastapi | 34,194 |

### Overall Winner: **sanic** (1/7 scenarios)

### Analysis Notes

- **Ping/JSON** (tiny payload): Measures pure request-routing overhead.
  Async frameworks (FastAPI, Aquilia, Sanic) typically dominate due to
  event-loop efficiency vs. gunicorn process model.

- **DB-read/write**: Async frameworks using `asyncpg` have an advantage
  over sync frameworks using `psycopg2` with thread pools.

- **Upload**: Tests I/O handling. Memory consumption matters here.

- **Stream**: Tests chunked transfer. Async generators are natural fit.

- **WebSocket**: Only async frameworks support this natively.
  Flask and Django are excluded from this scenario.

---

## Methodology

- **Isolation:** Each framework runs in its own Docker container (2 CPU, 512MB).
- **DB:** PostgreSQL 16 with shared schema and 1000 seeded rows.
- **Workers:** Sync (Flask/Django): gunicorn 4w×2t. Async: uvicorn/sanic 4 workers.
- **Load:** `wrk` for GET, `hey` for POST. 50 concurrent, 3 min steady-state.
- **Warmup:** 30s before each measurement.
- **Repetitions:** 3 runs per scenario, median reported.
- **Correctness:** Each endpoint validated before load test.
